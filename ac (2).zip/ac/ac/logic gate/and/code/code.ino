// Pin definitions based on the Proteus schematic
const int switch1Pin = 3;  // Input A (SW1)
const int switch2Pin = 2;  // Input B (SW2)
const int ledPin = 13;     // Output Y (LED-GREEN)

void setup() {
  // Configure input pins with their external pull-down resistors active
  pinMode(switch1Pin, INPUT);
  pinMode(switch2Pin, INPUT);
  
  // Configure LED pin as output
  pinMode(ledPin, OUTPUT);
}

void loop() {
  // Read the digital states of the switches (HIGH or LOW)
  bool A = digitalRead(switch1Pin);
  bool B = digitalRead(switch2Pin);
  bool Y = false;

  // --- UNCOMMENT ONLY ONE LOGIC GATE AT A TIME TO TEST ---

  //AND Gate (Output is HIGH only if both inputs are HIGH)
  Y = A && B;

  // 2. OR Gate (Output is HIGH if at least one input is HIGH)
  // Y = A || B;

  // 3. NAND Gate (Inverted AND gate)
  // Y = !(A && B);

  // 4. NOR Gate (Inverted OR gate)
  // Y = !(A || B);

  // 5. XOR Gate (Output is HIGH only if the inputs are different)
  //Y = A ^ B; 

  // Write the resulting logic state to the LED
  digitalWrite(ledPin, Y);
  
  delay(50); // Small stability delay for the simulation
}
