const int switch1Pin = 3;  
const int ledPin = 13;     

void setup() {
  pinMode(switch1Pin, INPUT);
  
  pinMode(ledPin, OUTPUT);
}

void loop() {
  bool A = digitalRead(switch1Pin);
  

  bool Y = !A;
  
  digitalWrite(ledPin, Y);
  
  delay(50);
}

