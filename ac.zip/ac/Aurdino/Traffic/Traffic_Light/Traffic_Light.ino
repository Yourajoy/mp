int red = 10;
int yellow = 9;
int green = 8;

void setup() {
  pinMode(red, OUTPUT);
  pinMode(yellow, OUTPUT);
  pinMode(green, OUTPUT);
}

void loop() {
  // Red ON
  digitalWrite(red, HIGH);
  digitalWrite(yellow, LOW);
  digitalWrite(green, LOW);
  delay(5000);

  // Red + Yellow ON (transition before green)
  digitalWrite(yellow, HIGH);
  delay(2000);

  // Green ON
  digitalWrite(red, LOW);
  digitalWrite(yellow, LOW);
  digitalWrite(green, HIGH);
  delay(5000);

  // Yellow ON (before red again)
  digitalWrite(green, LOW);
  digitalWrite(yellow, HIGH);
  delay(2000);

  digitalWrite(yellow, LOW);
}