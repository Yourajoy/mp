# Traffic Light Controller (Assembly)

A traffic light controller project written in **8086 Assembly**. It simulates a real-world traffic signal that cycles through Red, Yellow, and Green lights with fixed delays.

## Features

- Cycles through Red → Green → Yellow lights automatically
- Adjustable delay for each signal
- Controls lights through I/O ports (emu8086 Traffic Lights simulator)
- Clean, commented code that is easy to modify

## Project Structure

```
traffic-light/
├── README.md
├── traffic_light.asm    # Main source code
└── screenshots/         # Output screenshots
```

## How It Works

1. The program sets the initial state of the lights.
2. It sends a control byte to the output port to turn on the correct lights.
3. A delay loop keeps each light on for a fixed time.
4. The program moves to the next state and repeats forever.

### Signal Sequence

| State | North-South | East-West | Duration |
|-------|-------------|-----------|----------|
| 1 | Green | Red | Long |
| 2 | Yellow | Red | Short |
| 3 | Red | Green | Long |
| 4 | Red | Yellow | Short |

## Requirements

- [emu8086](https://emu8086-microprocessor-emulator.en.softonic.com/) (or any 8086 emulator with a Traffic Lights virtual device)
- Basic knowledge of 8086 registers, loops, and I/O instructions (`OUT`)

## How to Run

1. Open `traffic_light.asm` in emu8086.
2. Click **Emulate**, then **Run**.
3. Open the **Virtual Devices → Traffic Lights** window to watch the signals change.

## Key Concepts Used

- Registers (`AX`, `CX`, `DX`)
- `OUT` instruction for port output
- Nested loops for time delay
- Jumps and labels for the state cycle

## Code Outline

```asm
start:
    ; set lights for state 1
    mov al, state1
    out 4, al
    call delay

    ; set lights for state 2
    mov al, state2
    out 4, al
    call delay

    jmp start        ; repeat forever

delay proc
    mov cx, 0FFFFh
d1: loop d1
    ret
delay endp
```

> This is a simplified outline. See `traffic_light.asm` for the full program.

## Future Improvements

- [ ] Pedestrian crossing button
- [ ] Emergency mode (all red)
- [ ] Configurable timing from user input
- [ ] Seven-segment countdown display

## Screenshots

Add your output screenshots in the `screenshots/` folder and link them here:

```
![Traffic Light Output](screenshots/output.png)
```

## Author

Your Name

## License

MIT License
