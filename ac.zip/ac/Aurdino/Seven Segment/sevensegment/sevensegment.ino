int pin[] = {13, 12, 11, 10, 9, 8, 7};

// Segment mapping: a, b, c, d, e, f, g (Common Cathode)
byte digit2 = 0b1101101; // Displays '2'
byte digit7 = 0b1110000; // Displays '7'

void setup() {
  for (int i = 0; i < 7; i++) {
    pinMode(pin[i], OUTPUT);
  }
}

void displayDigit(byte code) {
  for (int i = 0; i < 7; i++) {
    digitalWrite(pin[i], bitRead(code, 6 - i));
  }
}

void loop() {
  displayDigit(digit2); // Show 2
  delay(1000);          // Wait 1 second

  displayDigit(digit7); // Show 7
  delay(1000);          // Wait 1 second
}