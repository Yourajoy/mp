const int ldrPin = A0;
const int lightPin = 13;

int ldrValue;
int threshold = 10;

void setup() {
  pinMode(lightPin, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  ldrValue = analogRead(ldrPin);

  Serial.println(ldrValue);

  if (ldrValue > threshold) {
    // Low light / night
    digitalWrite(lightPin, HIGH);
  } 
  else {
    // High light / day
    digitalWrite(lightPin, LOW);
  }

  delay(50);
}
